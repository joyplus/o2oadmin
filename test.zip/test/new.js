var adscreate = angular.module("Adscreate",[]);

adscreate.controller('ctrltype', ['$scope','$http', function($scope,$http){

	$scope.countries=[
    {
        "id": 0, 
        "name": "scott",
        "code": "001",
        "child": [
            {
                "id": 0, 
                "name": "123",
                "child": []
            },
            {
                "id": 1,
                "name": "234",
                "child": []
            },
            {
                "id": 2,
                "name": "345",
                "child": []
            }
        ]
    },
    {
        "id": 1, 
        "name": "liyongqin",
        "code": "002",
        "child": [
            {
                "id": 0, 
                "name": "123"
            },
            {
                "id": 1,
                "name": "234"
            },
            {
                "id": 2,
                "name": "456"
            },
            {
                "id": 3,
                "name": "wer"
            }
        ]
    },
    {
        "id": 2, 
        "name": "wfn",
        "code": "003",
        "child": [
            {
                "id": 0, 
                "name": "user"
            },
            {
                "id": 1,
                "name": "66"
            },
            {
                "id": 2,
                "name": "叶良辰"
            }
        ]
    }
];


	// $scope.$watch('vm.country', function(country) {
	// vm.province = null;
	// });

	// $scope.$watch('vm.province', function(province) {
	// vm.city = null;
	// });
}]);

adscreate.controller("multiCreativeController",['$scope','$http', function($scope,$http){
	$scope.addCreative = function(){
		
	}
}]);